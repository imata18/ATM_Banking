public enum AccountType {
	CHECKING,
	SAVINGS,
	LOANS,
	SECURITIES
}
