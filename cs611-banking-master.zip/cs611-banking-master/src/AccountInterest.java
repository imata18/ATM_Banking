public interface AccountInterest {
    public void applyInterest(long days);
}
