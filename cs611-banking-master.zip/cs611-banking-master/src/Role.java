public enum Role {
        CUSTOMER,
        MANAGER
}
